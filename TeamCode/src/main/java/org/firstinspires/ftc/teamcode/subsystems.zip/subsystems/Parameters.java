package org.firstinspires.ftc.teamcode.subsystems;


public class Parameters {
    public static String robot="gobilda";
}